package freemarker.poc.controller;

import freemarker.poc.service.FreemarkerService;
import freemarker.template.Configuration;
import freemarker.template.Template;

import java.io.File;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

public class FreemarkerController {
    public static void main(String[] args) {
        try {
            // Create a FreeMarker configuration
            Configuration cfg = new Configuration(Configuration.VERSION_2_3_31);
            cfg.setDirectoryForTemplateLoading(new File("src/main/resources/templates"));

            // Load the FreeMarker template
            Template template = cfg.getTemplate("Freemarker.ftl");

            // Create the data model (not using a model class in this example)

            // Render the template and print the output
//            Writer out = new OutputStreamWriter(System.out);
            Map dataModel = new HashMap<>();
            
//            FreemarkerService freemarkerController=new FreemarkerService();
            
            dataModel.put("obj", "Hello World!");
            
            StringWriter stringWriter=new StringWriter();
            template.process(dataModel, stringWriter);
            stringWriter.flush();
            System.out.println(stringWriter.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}




