package freemarker.poc.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;

import freemarker.cache.TemplateLoader;
import freemarker.cache.URLTemplateLoader;

public class RemoteUrlTemplateLoader  extends URLTemplateLoader {
	
	//environment vars
	private final String templateUrl;

    public RemoteUrlTemplateLoader(String templateUrl) {
        this.templateUrl = templateUrl;
    }
    
    protected URL getURL(String name) {
    	if (templateUrl == null) {
            // Handle the case where the templateUrl is null
            throw new IllegalArgumentException("templateUrl is not set");
        }
        try {
            // Construct the complete URL by appending the template name to the template URL
            String fullPath = templateUrl;
            return new URL(fullPath);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
	
    
}
