package freemarker.poc.controller;

import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

import freemarker.template.Configuration;
import freemarker.template.Template;

public class TemplateLoaderPOC {
	public static void main(String[] args) {
		try {
			// Set up Freemarker configuration with custom TemplateLoader
			String templateUrl = System.getenv("S3_URL");
			
			Configuration cfg = new Configuration(Configuration.VERSION_2_3_31);
			cfg.setTemplateLoader(new RemoteUrlTemplateLoader(templateUrl));
			Template template = cfg.getTemplate("Freemarker1.ftl");

			// Load the template using the remote URL directly
//			Template template = cfg
//					.getTemplate("https://fastcollab-test-asia.s3.ap-southeast-1.amazonaws.com/TestFiles/Freemarker.ftl");

			// Create the data model
			Map<String, Object> dataModel = new HashMap<>();
			dataModel.put("obj", "John Doe"); // Replace this with your actual data

			// Process the template and print the output
			StringWriter stringWriter = new StringWriter();
			template.process(dataModel, stringWriter);
			stringWriter.flush();
			System.out.println(stringWriter.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
