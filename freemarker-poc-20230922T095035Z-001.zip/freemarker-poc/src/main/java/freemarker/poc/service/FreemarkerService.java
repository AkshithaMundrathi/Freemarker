package freemarker.poc.service;

public class FreemarkerService {
	public String Freemarker() {
		return "Hi, This is My First Freemarker Project";
	}
}
